<h1 align="center">LoveTool - DDoS Attack</h1>
<em><h5 align="center">(Language: Python, Shell)</h5></em>
  
<p align="center">Vui lòng không tấn công các trang web liên quan tới chính phủ.</p>

<p align="center"><img src="https://i.imgur.com/slbFTPZ.jpeg" width="600" height="200" alt="Script"></p>
<p align="center"><img src="https://i.imgur.com/ZFPU2zj.png" width="800" height="500" alt="Demo DDoS"></p>

# Mothed

* SOCKET FLOOD
* GET FLOOD
* BYPASS

# Cách Setup

* Vào CH Play Hoặc Appstore Tải Google Cloud Để Chạy Tool Nhé!

* ```git clone https://github.com/ngkhanhh/LoveTool-leak```
* ```cd LoveTool```
* ```sh setup.sh```
* ```py abc.py```

# Cách Vào Tool

* ```cd LoveTool```
* ```python abc.py```

 





